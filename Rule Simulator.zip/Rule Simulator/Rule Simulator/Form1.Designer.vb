﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dgvDados = New System.Windows.Forms.DataGridView()
        Me.txtCaminhoArquivoJson = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtQtdTransactions = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtQtdDays = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtAmount = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.runVelocity = New System.Windows.Forms.Button()
        Me.btn3DS = New System.Windows.Forms.Button()
        Me.blockedTransactions = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.blockCBKUsers = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        CType(Me.dgvDados, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgvDados
        '
        Me.dgvDados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvDados.Location = New System.Drawing.Point(12, 59)
        Me.dgvDados.Name = "dgvDados"
        Me.dgvDados.Size = New System.Drawing.Size(1063, 350)
        Me.dgvDados.TabIndex = 0
        '
        'txtCaminhoArquivoJson
        '
        Me.txtCaminhoArquivoJson.Location = New System.Drawing.Point(12, 33)
        Me.txtCaminhoArquivoJson.Name = "txtCaminhoArquivoJson"
        Me.txtCaminhoArquivoJson.Size = New System.Drawing.Size(982, 20)
        Me.txtCaminhoArquivoJson.TabIndex = 1
        Me.txtCaminhoArquivoJson.Text = "data_transactions.json"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(1000, 31)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "Import"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 422)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(94, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Rule Configuration"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 454)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Velocity"
        '
        'txtQtdTransactions
        '
        Me.txtQtdTransactions.Location = New System.Drawing.Point(15, 470)
        Me.txtQtdTransactions.Name = "txtQtdTransactions"
        Me.txtQtdTransactions.Size = New System.Drawing.Size(91, 20)
        Me.txtQtdTransactions.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(112, 477)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(82, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "transactions per"
        '
        'txtQtdDays
        '
        Me.txtQtdDays.Location = New System.Drawing.Point(200, 470)
        Me.txtQtdDays.Name = "txtQtdDays"
        Me.txtQtdDays.Size = New System.Drawing.Size(91, 20)
        Me.txtQtdDays.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(297, 477)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(33, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "hours"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(402, 454)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(28, 13)
        Me.Label7.TabIndex = 9
        Me.Label7.Text = "3DS"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(402, 477)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(198, 13)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Sent to 3DS when amount is higher than"
        '
        'txtAmount
        '
        Me.txtAmount.Location = New System.Drawing.Point(606, 470)
        Me.txtAmount.Name = "txtAmount"
        Me.txtAmount.Size = New System.Drawing.Size(91, 20)
        Me.txtAmount.TabIndex = 11
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(703, 477)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(29, 13)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "reais"
        '
        'runVelocity
        '
        Me.runVelocity.Location = New System.Drawing.Point(15, 505)
        Me.runVelocity.Name = "runVelocity"
        Me.runVelocity.Size = New System.Drawing.Size(315, 36)
        Me.runVelocity.TabIndex = 13
        Me.runVelocity.Text = "Execute"
        Me.runVelocity.UseVisualStyleBackColor = True
        '
        'btn3DS
        '
        Me.btn3DS.Location = New System.Drawing.Point(405, 505)
        Me.btn3DS.Name = "btn3DS"
        Me.btn3DS.Size = New System.Drawing.Size(327, 36)
        Me.btn3DS.TabIndex = 14
        Me.btn3DS.Text = "Execute"
        Me.btn3DS.UseVisualStyleBackColor = True
        '
        'blockedTransactions
        '
        Me.blockedTransactions.Location = New System.Drawing.Point(15, 547)
        Me.blockedTransactions.Name = "blockedTransactions"
        Me.blockedTransactions.Size = New System.Drawing.Size(315, 36)
        Me.blockedTransactions.TabIndex = 15
        Me.blockedTransactions.Text = "Blocked Transactions"
        Me.blockedTransactions.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(405, 547)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(327, 36)
        Me.Button5.TabIndex = 16
        Me.Button5.Text = "3DS List"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(808, 454)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(70, 13)
        Me.Label8.TabIndex = 17
        Me.Label8.Text = "Chargebacks"
        '
        'blockCBKUsers
        '
        Me.blockCBKUsers.Location = New System.Drawing.Point(811, 505)
        Me.blockCBKUsers.Name = "blockCBKUsers"
        Me.blockCBKUsers.Size = New System.Drawing.Size(264, 36)
        Me.blockCBKUsers.TabIndex = 18
        Me.blockCBKUsers.Text = "Block Users"
        Me.blockCBKUsers.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(811, 547)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(264, 36)
        Me.Button7.TabIndex = 19
        Me.Button7.Text = "Block List"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(808, 477)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(108, 13)
        Me.Label9.TabIndex = 20
        Me.Label9.Text = "Block users with CBK"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1087, 648)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.blockCBKUsers)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.blockedTransactions)
        Me.Controls.Add(Me.btn3DS)
        Me.Controls.Add(Me.runVelocity)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtAmount)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtQtdDays)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtQtdTransactions)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.txtCaminhoArquivoJson)
        Me.Controls.Add(Me.dgvDados)
        Me.Name = "Form1"
        Me.Text = "Rule Simulator"
        CType(Me.dgvDados, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents dgvDados As DataGridView
    Friend WithEvents txtCaminhoArquivoJson As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtQtdTransactions As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtQtdDays As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents txtAmount As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents runVelocity As Button
    Friend WithEvents btn3DS As Button
    Friend WithEvents blockedTransactions As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents blockCBKUsers As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Label9 As Label
End Class
