﻿Imports Rule_Simulator.Form1

Public Class BlockedList

    Public Property BlockedData As List(Of Dados)
    Private Sub BlockedList_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Vincular a fonte de dados da datagridview DataGridView1 à propriedade pública que contém a lista de objetos
        DataGridView1.DataSource = BlockedData

        'Opcional: ajustar as colunas da datagridview
        DataGridView1.AutoResizeColumns()
    End Sub


End Class